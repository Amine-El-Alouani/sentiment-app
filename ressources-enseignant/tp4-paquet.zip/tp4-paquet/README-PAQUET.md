# Paquet TP4 : tests approfondis et qualité (semaine 4)

**Module :** Développement et déploiement d'applications intelligentes · **Auteur :** A. Larhlimi

| Élément | Pour qui | Contenu |
| --- | --- | --- |
| `tp4-tests-qualite-kit.zip` | Étudiants | Kit, énoncé, marche à suivre (contrôles T21 à T27) |
| `corrige/` | Enseignant | Code et tests corrigés, jeu d'or d'exemple, `CORRIGE-TP4.md` avec toutes les valeurs mesurées |

## Calendrier de diffusion

| Quand | Quoi |
| --- | --- |
| J-7 | Prérequis : le TP3 terminé, `pytest -q` à 48 passed, CI verte |
| J-2 | Énoncé et kit ; les binômes rédigent leurs 20 avis du jeu d'or avant la séance |
| Jour J | Diapositives de la semaine 4 (deck, lot 5), puis la séance |
| J+1 | Corrigé |

## Comptes de référence

Dépôt de référence (TP1 à 38 tests) : 48 passed en fin de TP3 ; `1 failed, 51 passed, 1 skipped` juste après l'installation du kit ; `83 passed, 2 xfailed` avec le corrigé. Un dépôt qui contient déjà l'interface Streamlit compte 3 tests de plus à chaque étape.

## Vérification

Chaîne rejouée de bout en bout : TP2 (jeu de démonstration, F1 0,879), TP3 (`api/`, 6 tests), installation du kit, chaque étape du corrigé, crochet pre-commit, puis CI simulée sur un clone neuf sans modèle. Python 3.12, FastAPI 0.115.0, outils aux versions de `requirements-dev.txt`.
