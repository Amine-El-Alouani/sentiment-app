# TP4 : corrigé et valeurs de référence (enseignant)

**Ne pas distribuer avant J+1.** Toutes les valeurs ci-dessous ont été mesurées sur la chaîne TP2 (jeu de démonstration) puis TP3 (API `api/`), modèle entraîné par `python src/train.py`. Les comptes de tests supposent le dépôt de référence (TP1 à 38 tests) ; un dépôt qui contient déjà l'interface Streamlit en compte 3 de plus.

## Fichiers du corrigé

| Fichier | Ce qui change |
| --- | --- |
| `api/schemas.py` | `field_validator` qui refuse les blancs (règle `str.strip()`) ; type `Label` en `Literal` ; `PredictResponse.label: Label` |
| `api/model.py` | `SEUIL_ABSTENTION = 0.60` ; `CORRESPONDANCE` explicite ; `TypedDict Prediction` ; classes vérifiées au démarrage |
| `api/main.py` | Plus de conversion `ValueError` → 422 : toute panne du modèle donne 500 (`from None`) ; annotations ; `# pragma: no cover` justifié sur le bloc `__main__` |
| `src/predict.py` (TP2) | `TypedDict Resultat` pour le retour de `predict()` |
| `src/evaluate.py` (TP2) | Import inutilisé retiré, `zip(..., strict=True)` (remarques de ruff) |
| `tests/test_api.py` (TP3) | Ordre des imports (`ruff --fix`) ; aucun test à changer avec un seuil de 0,60 |
| `tests/test_limites.py` | 8 cas paramétrés avec contrôle de forme, 2 propriétés hypothesis |
| `tests/test_integration.py` | Démarrage, modèle absent, 503, pannes `RuntimeError` et `ValueError`, classes inconnues |
| `data/jeu_or.csv` | Un jeu d'or d'exemple : 20 avis, 6 difficiles, 2 erreurs déclarées |

## Contrôle par contrôle, ce que l'on mesure

**T21, départ.** Après installation et `pip install -r requirements-dev.txt` : `1 failed, 51 passed, 1 skipped`. Couverture de `api/` : **91 %** (69 instructions, 6 manquantes, toutes dans `main.py` : le 503 de `_classifier`, la branche `except Exception` du 500, le bloc `__main__`). ruff : **8 remarques** sur TP2 et TP3 (B904 ×2 dans `main.py`, F401 et I001 dans `model.py`, F401 et B905 ×2 dans `evaluate.py`, I001 dans `test_api.py`). mypy : `Success`, rien sur les étiquettes.

**B, ce que les tests trouvent.** Avant correction, 2 échecs sur 10 : le cas « espaces seuls » (422, mais `detail` est la chaîne `"texte vide"` produite par `predict()` via le `except ValueError` de `main.py`, alors que `""` donne la liste de Pydantic) et la propriété des blancs. Le plus petit contre-exemple trouvé par hypothesis est `'\x85'` (NEL) : `str.strip()` le retire, donc le schéma laisse passer un texte que le modèle refuse. Après le `field_validator` : **10 passed**, trois fois (T22, T23).

**C, le modèle sans vocabulaire.** Tout texte sans mot connu (« xqzvb wlkptr grombu », « Lorem ipsum dolor sit amet », et même « Bonjour ») reçoit **NEGATIVE à 0,5162** : le vecteur TF-IDF est nul, il ne reste que l'ordonnée à l'origine, qui penche du côté négatif (0,5162 contre 0,4838). Après l'abstention : `INDETERMINE`, 0,5162 (T24).

Courbe du seuil, jeu de test du TP2 (58 avis) :

| Seuil | Répond à | Part | Exactitude | Erreurs | Vers un humain |
| --- | --- | --- | --- | --- | --- |
| 0,50 | 58 | 100 % | 0,879 | 7 | 0 |
| 0,55 | 47 | 81 % | 0,915 | 4 | 11 |
| 0,60 | 42 | 72 % | 0,952 | 2 | 16 |
| 0,65 | 41 | 71 % | 0,976 | 1 | 17 |
| 0,70 | 37 | 64 % | 1,000 | 0 | 21 |
| 0,75 | 29 | 50 % | 1,000 | 0 | 29 |
| 0,80 | 13 | 22 % | 1,000 | 0 | 45 |
| 0,85 | 6 | 10 % | 1,000 | 0 | 52 |
| 0,90 et 0,95 | 0 | 0 % | | 0 | 58 |

Au-delà de 0,85, le modèle ne répond plus jamais : sa confiance maximale sur ce jeu reste sous 0,90. À 0,60, 16 avis sur 58 partent vers un humain et les erreurs passent de 7 à 2 ; à 0,70, plus aucune erreur, mais 21 avis renvoyés.

**Jeu d'or d'exemple (T25).** À 0,60 : 15 justes, 3 abstentions, 2 erreurs franches, déclarées en `xfail(strict=True)` : « Je ne recommande pas ce vendeur » (POSITIVE à 0,69 : le sac de mots compte « recommande », pas « ne pas ») et « Scénario ennuyeux, je me suis endormi avant la fin » (POSITIVE à 0,66 : vocabulaire du cinéma absent du jeu de démonstration). Résultat : `19 passed, 2 xfailed`. À 0,70 : 11 justes, 9 abstentions, aucune erreur franche ; les deux `xfail` deviennent `XPASS(strict)` et font échouer le test, ce qui oblige à retirer leurs déclarations. C'est le mécanisme attendu.

**D, ce que les tests trouvent.** Sur le `main.py` du TP3, 2 échecs sur 6 : la panne `ValueError("bug interne")` reçoit **422 avec le message interne** dans le corps (une panne du serveur présentée comme une faute du client, et une fuite d'information), et le test des classes inconnues tant que l'étape E.3 n'est pas faite. Couverture après les tests d'intégration, avant toute exclusion : **97 %** (seules les 2 instructions du bloc `__main__` restent) ; avec le corrigé et l'exclusion justifiée : **100 %** (T26).

**E, mypy.** Silencieux tant que `predict()` renvoie un `dict`. Avec les `TypedDict` et `.upper()` conservé : `Incompatible types (expression has type "str", TypedDict item "label" has type "Literal['POSITIVE', 'NEGATIVE', 'INDETERMINE']")`. Avec la correspondance explicite : `Success`. Ce que `ruff --fix` ne règle pas : les deux B905 de `evaluate.py` (`strict=True`) et les deux B904 de `main.py` : l'un disparaît avec la branche `ValueError` supprimée à l'étape D, l'autre se règle par `from None`.

**pre-commit.** Un `import os` inutile : ligne `ruff` en `Failed`, commit refusé. Un `.upper()` remis dans `model.py` : `ruff Passed`, `mypy Failed`, commit refusé.

**T27, fin.** `ruff check .` : `All checks passed!` ; `mypy api` : `Success: no issues found in 4 source files` ; `pytest -q` : **83 passed, 2 xfailed** sur le dépôt de référence. CI simulée sur un clone neuf, sans modèle : entraînement, ruff, mypy, `pytest --cov-fail-under=95`, tout vert.

## Ce que ruff et mypy n'ont pas vu

Aucun des quatre défauts réels (deux formes de 422, panne `ValueError` convertie en 422 avec fuite du message, étiquette forcée sur un texte inconnu, contrat d'étiquette non vérifié) ne figurait dans les 8 remarques de départ. B904 pointe la bonne ligne pour une autre raison (le chaînage des exceptions), et mypy ne pouvait rien voir à travers un `dict`. C'est la conclusion attendue dans la partie 5 du compte rendu : l'analyse statique complète les tests, elle ne les remplace pas.

## Pour aller plus loin, la mesure de référence

Sur le jeu de démonstration de ce TP2, seuls 192 textes sont distincts sur 290, et **27 des 58 avis de test figurent mot pour mot dans l'entraînement** ; aucun texte ne porte deux étiquettes. Le F1 de 0,879 du TP2 est donc optimiste. Un binôme qui écrit les tests de données le découvre.

## Points de correction

| Ce qu'on regarde | Où |
| --- | --- |
| La forme du 422, pas seulement son code | `tests/test_limites.py` |
| La règle `str.strip()` commune au schéma et au modèle | `api/schemas.py` |
| Un seuil choisi sur la courbe, avec son coût (avis renvoyés) | `docs/semaine4.md`, partie 3 |
| Des cas difficiles gardés, des erreurs déclarées et expliquées | `data/jeu_or.csv` |
| `monkeypatch` et `cache_clear()`, pas d'état qui fuit d'un test à l'autre | `tests/test_integration.py` |
| Aucune exclusion de couverture autre que le bloc `__main__`, et justifiée | `api/`, `docs/semaine4.md` |
| Des chiffres qui sont les leurs, pas ceux de ce corrigé | `docs/semaine4.md` |
