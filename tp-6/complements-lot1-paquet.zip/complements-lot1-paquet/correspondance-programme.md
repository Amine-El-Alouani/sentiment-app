# Correspondance entre le programme officiel et le support (après le lot 1)

C : couvert, cours et pratique ; T : couvert en cours, TP à finaliser ; P : partiel ; A : absent.
Le décompte initial comptait une rubrique de trop parmi les couvertes : il est corrigé ici.

| Programme | Avant | Après le lot 1 | Où, ou lot prévu |
| --- | --- | --- | --- |
| 1.1 Définitions, histoire, applications | C | C | Introduction, semaine 1 |
| 1.2 Règles, ML, DL, génératif, RAG | C | C | Semaine 1, TP1 |
| 1.3 TensorFlow, PyTorch, bibliothèques | P | P | Lot 6 |
| 1.4 Cycle de vie | C | C | Introduction |
| 1.5 Choix d'approche, critères, métriques | C | C | TP1, TP2, TP4 |
| 1.6 Éthique, biais, validation humaine | P | **C** | TP1 (fiches), TP4 (abstention, **étape F : biais**), TP6 (**fiche modèle**) |
| 2.1 Python, environnements, projet | C | C | TP1 |
| 2.2 FastAPI ; aperçu Django, Pyramid, Express | P | P | TP3 ; aperçu au lot 6 |
| 2.3 API REST : versionnement, authentification | P | P | TP3, TP4 ; lot 3 |
| 2.4 Intégration d'un modèle | C | C | TP2, TP3 |
| 2.5 Streamlit : interface, visualisation, démonstration | P | P | TP5 (**étape G : graphiques**) ; démonstration déployée au lot 3 |
| 2.6 Packaging, wheel, documentation, tests | C | C | TP6 (**fiche modèle**) |
| 2.7 Java/Spring Boot | A | A | Lot 3 |
| 3.1 DevOps et MLOps | C | C | Introduction, CI depuis le TP1 |
| 3.2 MLflow | T | T | Lot 2 |
| 3.3 DVC | T | T | Lot 2 |
| 3.4 Docker, Docker Compose | T | T | Lot 3 |
| 3.5 CI/CD simplifié | P | P | CI depuis le TP1 ; déploiement au lot 3 |
| 3.6 Kubeflow ou Azure ML | A | A | Lot 5 |
| 3.7 Logs, monitoring, latence, coût | P | P | Lot 3 |
| 4.1 Appel d'un modèle de langage | T | T | Lot 4 |
| 4.2 Prompts structurés, sorties JSON | P | P | Lot 4 |
| 4.3 Embeddings, index vectoriel | T | T | Lot 4 |
| 4.4 RAG avec citations | T | T | Lot 4 |
| 4.5 Hallucinations, injection, confidentialité | P | P | Lot 4 |
| 5.1 Authentification, secrets, protection | P | P | TP1 (secrets) ; lot 3 |
| 5.2 Tests fonctionnels, d'API, qualité | C | C | TP3, TP4, TP5 |
| 5.3 Précision, rappel, F1 ; RAG | P | P | TP2, TP4 (**biais par groupe**) ; RAG au lot 4 |
| 5.4 Explicabilité, LIME ou SHAP | P | **C** | Semaine 11 ; TP2 (**étape F : SHAP**) |
| 5.5 Documentation des modèles, limites, usage | P | **C** | TP6 (**fiche modèle**), comptes rendus |

**Décompte des 30 points** : avant, 9 C, 6 T, 13 P, 2 A ; après le lot 1, **12 C**, 6 T, 10 P, 2 A.

| TP du programme | TP du support | Après le lot 1 |
| --- | --- | --- |
| TP 1 : FastAPI pour un modèle | TP2, TP3 | Couvert |
| TP 2 : API consommée par une application web | TP3, TP5 | Couvert |
| TP 3 : Streamlit, analyse et visualisation | TP5 | **Couvert** (étape G) |
| TP 4 : package, setuptools, wheel, tests | TP6 | Couvert |
| TP 5 : MLflow et DVC | TP7 | Lot 2 |
| TP 6 : Docker Compose | TP8 | Lot 3 |
| TP 7 : mini-RAG avec citations | TP9 | Lot 4 |
| TP 8 : Kubeflow ou Azure ML | TP10 | Lot 5 |
