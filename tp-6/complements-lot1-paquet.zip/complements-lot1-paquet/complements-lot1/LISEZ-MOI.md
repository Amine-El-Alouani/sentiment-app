# Compléments du lot 1 : explicabilité, biais, graphiques, fiche modèle

Quatre étapes ajoutées à des TP existants, pour couvrir des points du programme du module :
l'explicabilité (chapitre 5, point 4), les biais (chapitre 1, point 6), la visualisation dans
Streamlit (chapitre 2, point 5) et la documentation du modèle (chapitre 5, point 5).

| Étape | TP | Durée | Contrôle | Marche à suivre |
| --- | --- | --- | --- | --- |
| F : ce que regarde le modèle | TP2 | 20 min | C6 | `tp2-explicabilite/TP2-ETAPE-F.md` |
| F : le modèle sert-il tous les avis de la même façon ? | TP4 | 20 min | T27a | `tp4-biais/TP4-ETAPE-F.md` |
| G : deux graphiques dans l'onglet fichier | TP5 | 20 min | T34a | `tp5-graphiques/TP5-ETAPE-G.md` |
| G : la fiche modèle | TP6 | 30 min | T41a | `tp6-fiche-modele/TP6-ETAPE-G.md` |

## Installer

Décompressez l'archive à côté de votre dépôt, puis, depuis n'importe quel dossier :

```powershell
python C:\IA-DEV\complements-lot1\appliquer_complements.py C:\IA-DEV\sentiment-app --etape toutes --simulation
python C:\IA-DEV\complements-lot1\appliquer_complements.py C:\IA-DEV\sentiment-app --etape toutes
python -m pytest -q
```

- **Dépôt déjà en fin de TP6** : `--etape toutes` pose les quatre étapes d'un coup. Faites-les ensuite
  dans l'ordre TP2, TP4, TP5, TP6.
- **Pendant le semestre** : posez chaque étape à la fin de son TP, avec `--etape tp2`, `tp4`, `tp5` ou `tp6`.
- Le script ne remplace aucun fichier : un fichier déjà présent est signalé et laissé tel quel. Une
  étape dont le TP n'est pas installé est ignorée, avec un message.
- Si votre chemin contient des espaces, mettez-le entre guillemets.

## Ce que le script change dans la CI

Il épingle pytest (`"pytest==8.3.*"`, comme dans `requirements.txt`) et ajoute SHAP sur la ligne
d'installation de `.github/workflows/ci.yml`. Sans cet épinglage, la CI installe pytest 9, dont
`monkeypatch` ne restaure plus un attribut de `app.state` : un test du TP5 laisse alors l'API sans
modèle, et le test suivant échoue en CI alors que tout passe sur votre poste.

## Après installation, en fin de TP6

`python -m pytest -q` affiche **13 failed** de plus qu'avant : ce sont les tests de la fiche modèle,
qui échouent tant qu'elle est vide, comme les fiches de cadrage du TP1. Tous les autres passent :
4 tests d'explicabilité, 8 de biais et 4 de graphiques s'ajoutent aux vôtres.
