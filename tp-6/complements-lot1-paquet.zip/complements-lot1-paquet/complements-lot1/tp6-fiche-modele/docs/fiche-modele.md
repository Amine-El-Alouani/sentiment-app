# Fiche modèle : sentiment-app

> Une fiche modèle dit, en une page, ce que fait le modèle, sur quelles données il a appris, ce qu'il
> vaut, où il se trompe et dans quelles conditions on peut s'en servir. Remplacez chaque consigne par
> votre texte ; les lignes qui commencent par « > » ne comptent pas. Les tests vérifient que chaque
> rubrique est remplie et que les chiffres cités sont ceux du dépôt.

## Identité du modèle

> Nom, version du paquet (celle de sentiment_app.__version__), date d'entraînement, type de modèle.

## Usage prévu

> Pour qui, pour quelle décision, dans quel flux de travail (relation client, avis en français).

## Usages exclus

> Ce pour quoi le modèle ne doit pas servir : au moins deux cas.

## Données d'entraînement

> Source, taille, répartition des classes, langue, domaine ; ce que ces données ne couvrent pas.

## Performances mesurées

> Le F1 macro et le rappel des négatifs, tels que dans models/metrics.json ; le seuil d'abstention de
> l'API et ce qu'il change (part des avis traités, erreurs restantes, avis envoyés à un humain).

## Limites connues

> Les cas où le modèle se trompe, avec un exemple : ce que montrent l'étape F du TP2 et le jeu d'or.

## Biais mesurés

> Les groupes d'avis moins bien servis, chiffres de python src/biais.py à l'appui.

## Explicabilité

> Ce que montre python src/expliquer.py : les termes qui pèsent le plus, et ce que cela révèle.

## Conditions d'usage

> Ce qu'un humain doit vérifier, quand, et ce qu'on ne doit jamais décider sur la seule foi du modèle.

## Maintenance

> Quand réentraîner, avec quelle version de scikit-learn, comment indiquer le modèle au paquet.
