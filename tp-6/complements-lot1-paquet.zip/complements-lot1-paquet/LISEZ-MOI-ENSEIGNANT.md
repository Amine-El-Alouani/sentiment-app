# Lot 1 : paquet enseignant (ne pas distribuer)

Contenu : le kit `complements-lot1/` tel que distribué, `fiche-modele-corrige.md`, la table
`correspondance-programme.md`, et ce document.

## Valeurs mesurées

Mesures faites sous Python 3.11, scikit-learn 1.5.2, SHAP 0.46.0, sur la chaîne TP1 à TP6 corrigée,
avec le modèle de démonstration (F1 0.879).

| Contrôle | Valeur |
| --- | --- |
| C6 | Termes les plus influents : « je » +0.771, « que je » +0.764, « en » +0.683 ; « arrivée », « cassé » -0.923, « au » -0.689. Avis mitigé : negative à 0.5335 ; 20 termes vers negative (-1.0061), 13 vers positive (+0.9177), absents -0.0345, base -0.0114, sortie -0.1343 |
| T27a | Retournement : 17 avis, exactitude 0.588, 7 erreurs, 15 vers un humain, 2 restantes ; direct : 41 avis, 1.000. Long : 27 avis, 0.741 ; court : 31 avis, 1.000 ; long et direct : 10 avis, 1.000 |
| T34a | Fichier d'exemple : positif 3, négatif 2, à vérifier 1, refus 0 ; confiances 1, 1, 3, 1, 0 de 50 à 100 % |
| T41a | Fiche vide : 13 failed, 1 passed ; fiche corrigée : 14 passed |

Comptes de tests, avant puis après l'étape : TP2-TP3 11 puis 15 ; TP4 46 puis 54 ; TP5 58 puis 62 ;
fin de TP6 64, puis 81 passed et 13 failed voulus, puis 94 passed et 2 xfailed avec la fiche remplie.
Les étudiants ont en plus les 38 tests du TP1. La CI, rejouée sur un clone neuf, est verte : couverture
de l'API à 100 %, roue construite et installée hors du dépôt.

## Correction apportée à la chaîne existante : pytest 9

La CI installait pytest sans version. Avec pytest 9, `monkeypatch` ne restaure plus un attribut de
`app.state` : `test_modele_non_charge` (TP5) laisse l'API sans modèle, et `test_lot_et_resume` échoue
en CI (trois « REFUS OU ERREUR »), alors que tout passe sur les postes, qui ont pytest 8.3.

- Le script des compléments épingle `"pytest==8.3.*"` dans la CI.
- `tp5-interface-kit.zip` est republié : ce test est réécrit sans `monkeypatch`, et passe sous pytest 9.
- **À faire de votre côté** : épingler pytest dans la CI du dépôt du cours.
- Un binôme déjà au TP5 dont la CI est rouge sur `test_lot_et_resume` : appliquer le script, ou
  remplacer le test par celui du kit republié.

## Intégration aux grilles, sans changer le total

| TP | Étape | Proposition |
| --- | --- | --- |
| TP2 | F, explicabilité | Dans le critère d'analyse des erreurs : la phrase sur les termes influents est attendue |
| TP4 | F, biais | Dans le critère consacré aux limites du modèle : les écarts par groupe, avec leurs effectifs |
| TP5 | G, graphiques | Dans le critère de l'interface : les deux graphiques et leurs tests |
| TP6 | G, fiche modèle | 0,5 point repris sur « La commande sentiment » (2 puis 1,5) et ajouté au critère de documentation (1,5 puis 2) |

Points de correction : la fiche doit citer les mesures du binôme ; une fiche identique d'un binôme à
l'autre est un signal d'alerte, comme un compte rendu recopié.

## Calendrier de diffusion

| Moment | Action |
| --- | --- |
| J-7 | Poser l'étape sur votre clone de référence ; vérifier les valeurs de ce document |
| J-2 | Rappeler `pip install -r requirements.txt` (SHAP y est épinglé depuis le TP1) |
| Jour J | Distribuer la marche à suivre de l'étape ; l'étape se fait en fin de séance, ou en préparation de la suivante |
| J+1 | Relève : le contrôle de l'étape dans le journal, les nouveaux tests, la CI verte |
